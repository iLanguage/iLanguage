package com.racersystems.jracer;


public class PhonontRacerTest {
    //@SuppressWarnings("unchecked")
	public static void main(String[] args) {

    	// please adjust this path to match your environment: 

    	// String peopleAndPets = "\"C:/jracer-2-0/demo/people+pets.owl\""; 

    	//String peopleAndPets = "\"C:\\\\Program Files\\\\Protege_4.0.1\\\\RacerPro-20-Preview\\\\JRacer-2-0-preview\\\\jracer-2-0\\\\demo\\\\people+pets.owl\""; 
    	//String peopleAndPets = "\"C:\\\\Program Files\\\\Protege_4.0.1\\\\RacerPro-20-Preview\\\\comp6531\\\\phonont.v1.utf8-font.owl\"";
    	String peopleAndPets = "\"C:\\\\Program Files\\\\Protege_4.0.1\\\\RacerPro-20-Preview\\\\comp6531\\\\family-toplaywith.racer\"";
    	String ip = "localhost";
    	int port = 8088;

    	RacerClient racer = new RacerClient(ip,port);		

    	try {

    	    racer.openConnection();

    	    racer.loggingOn();
    	    racer.sendRaw("(logging-on)");
    	
    	    racer.fullReset();

    	    racer.racerReadFile(peopleAndPets); 

    	    System.out.println(racer.taxonomy()); 
    	    System.out.println(racer.taxonomy$()); 

    	    
//    	    System.out.println("send raw");
  //  		String coreQuery= racer.sendRaw("(retrieve (?x) (?x Inuktitut-Orthographic-Core) )");
    //		System.out.println(coreQuery);

    	    
    	    
    	    RacerList<RacerList>
    		res1 = (RacerList<RacerList>)
    		racer.taxonomy$(); 

    	    for (RacerList triple : res1) {
    		System.out.println("--------"); 
    		System.out.println("Concept : "+triple.getValue().get(0)); 
    		System.out.println("Parents : "+triple.getValue().get(1)); 
    		System.out.println("Children: "+triple.getValue().get(2)); 
    	    } 
    	    
    	    System.out.println(racer.currentAbox()); 
    	    System.out.println(racer.currentAbox$()); 

    	    racer.instanceM("i","C"); 

    	    System.out.println(racer.aboxConsistentP()); 
    	    System.out.println(racer.aboxConsistentP(racer.currentAbox())); 
    	    System.out.println(racer.aboxConsistentMP(racer.currentAbox())); 
    	    System.out.println(racer.aboxConsistentP(racer.currentAbox$())); 
    	    System.out.println(racer.aboxConsistentMP(racer.currentAbox$())); 

    	    System.out.println(racer.racerAnswerQuery("(?x ?y)",
    						      "(and (?x #!:person) (?x ?y #!:has_pet))")); 

 

    	    System.out.println(racer.describeAllQueries()); 
    	    System.out.println(racer.describeAllQueries(true)); 
    	    System.out.println(racer.describeAllQueries(false)); 
    	    System.out.println(racer.describeAllQueries$(true)); 
    	    System.out.println(racer.describeAllQueries$("nil")); 
    	    System.out.println(racer.describeAllQueries$("t")); 
    	    System.out.println(racer.describeAllQueries$(new RacerSymbol("nil"))); 
    	    System.out.println(racer.describeAllQueries$(new RacerSymbol("t"))); 
    	    System.out.println(racer.describeAllQueries(new RacerSymbol("nil"))); 
    	    System.out.println(racer.describeAllQueries(new RacerSymbol("t"))); 

    	
    	    String res4 = 
    		racer.racerAnswerQuery("(?x)",
    				       "(?x #!:person)",
    				       ":how-many",3,
    				       ":exclude-permutations",true);


 
    	    //racer.withUniqueNameAssumption(); 

    	    System.out.println("Checking if the abox is consistent now.");
    	    //racer.aboxConsistentP(); 
    	    
    	    racer.withNrqlSettings(":how-many-tuples",1); 
    	    System.out.println(racer.racerAnswerQuery$("(?x)","(?x #!:person)")); 

    	    racer.endWithNrqlSettings(); 

    	    System.out.println(racer.racerAnswerQuery$("(?x)","(?x #!:person)")); 

    	    RacerList<RacerSymbol> head = new RacerList();
    	    head.getValue().add(new RacerSymbol("?x")); 
    	    RacerList body = (RacerList)racer.parseRacerAnswer("(?x #!:person)"); 
    	    System.out.println(racer.racerAnswerQuery$(head,body)); 
    	    racer.endWithUniqueNameAssumption(); 

    	    System.out.println(racer.racerAnswerQuery(head,body)); 

    	    // sometimes, type casts and dynamic type checks can't be avoided: 

    	    for(String concept : new String[] {"top","#!:person","#!:mad_cow","#!:Orthographic-ᐊ","bottom"}) {
    		
    		System.out.println(); 
    		System.out.println("Retrieving instances of "+concept+":"); 

    		RacerResult 
    		    res7 = (RacerResult)
    		    racer.conceptInstancesM$(concept); 

    		if (res7 instanceof RacerSymbol) { // no instances? nil can't be cast in a RacerList!
    		    System.out.println("No instances!"); 
    		} else {
    		    for (RacerSymbol ind : (RacerList<RacerSymbol>) res7) {
    			System.out.println(ind); 
    		    }
    		}
    	    }

    	} catch (Exception e) {

    	    e.printStackTrace();
    	    
    	}
    	
        }
}
