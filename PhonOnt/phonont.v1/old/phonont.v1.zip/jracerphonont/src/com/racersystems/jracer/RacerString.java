package com.racersystems.jracer;

public class RacerString extends RacerLiteral {
    public String value; 

    public String getValue() { return value; }

    public RacerString(String value) {
	this.value=value; 
    }

}
