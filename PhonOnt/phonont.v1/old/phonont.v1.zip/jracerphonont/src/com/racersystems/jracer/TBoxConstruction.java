/**
 * 
 */
package com.racersystems.jracer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author gina
 *
 */
public class TBoxConstruction {
	public static void main(String[] args) {
		String s = null;
		String pythonPath = "C:\\Python26\\python.exe";
		String mappingsPath ="pythonsrc\\tboxes\\";
		String mappingFileName = "Default";
		String[] mappingFileNames = {"English","english-orthography2phonemes.txt","InuktitutRomanized","inuktitutromanized-orthography2phonemes.txt","Inuktitut","inuktitut-orthography2phonemes-incomplete.txt"}; 

		String language = "Default";

		String populatePhonemeTboxScript = "pythonsrc\\populate-phonemesMappings.v2.py";
		String TboxOutputFile ="-tbox.txt";
		String combineTboxesScript="pythonsrc\\combine-Tboxes.v2.py";
		String outFileName = mappingsPath+"phonemes-combined-Tbox.owl";
		
		String tboxArray = "pythonsrc\\data\\phonont-header.txt ";  //no its not supposed to be the mappings directory
		for (String mapping : mappingFileNames) {
			//To remove language out of the file array
			String pattern = "(.*)(\\W+)(.*)";
			Pattern r = Pattern.compile(pattern);
			Matcher m = r.matcher(mapping);
			if (!(m.find( ))) {
				continue;
			}
			//for all files, create the data files
			tboxArray=tboxArray+mappingsPath+mapping+TboxOutputFile+" ";
		}
		tboxArray=tboxArray+" pythonsrc\\data\\phonont-footer.txt ";
		System.out.println("This is the args list for combining the Tboxes: "+tboxArray);


		try{
			//http://devdaily.com/java/edu/pj/pj010016/
			for (String item : mappingFileNames) {
				//System.out.println(item);

				//To get the language out of the file array
				String pattern = "(.*)(\\W+)(.*)";
				Pattern r = Pattern.compile(pattern);
				Matcher m = r.matcher(item);
				if (!(m.find( ))) {
					System.out.println("Language is "+item);
					language = item;
					continue;
				}
				//for all files, create the data files
				System.out.println("File is "+item);
				mappingFileName = item;

				Process p = Runtime.getRuntime().exec(pythonPath+" "+populatePhonemeTboxScript+" "+mappingsPath+mappingFileName+" "+language);

				BufferedReader stdInput = new BufferedReader(new 
						InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(new 
						InputStreamReader(p.getErrorStream()));

				// read the output from the command
				//System.out.println("Here is the standard output of the command:\n");
				while ((s = stdInput.readLine()) != null) {
					System.out.println(s);
				}

				// read any errors from the attempted command
				//System.out.println("Here is the standard error of the command (if any):\n");
				while ((s = stdError.readLine()) != null) {
					System.out.println(s);
				}



				try {
					p.waitFor();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			Process p = Runtime.getRuntime().exec(pythonPath+" "+combineTboxesScript+" "+outFileName+" "+tboxArray);

			BufferedReader stdInput4 = new BufferedReader(new 
					InputStreamReader(p.getInputStream()));

			BufferedReader stdError4 = new BufferedReader(new 
					InputStreamReader(p.getErrorStream()));

			// read the output from the command
			//System.out.println("Here is the standard output of the command:\n");
			while ((s = stdInput4.readLine()) != null) {
				System.out.println(s);
			}

			// read any errors from the attempted command
			//System.out.println("Here is the standard error of the command (if any):\n");
			while ((s = stdError4.readLine()) != null) {
				System.out.println(s);
			}

			try {
				p.waitFor();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			System.exit(0);

		}
		catch (IOException e) {
			System.out.println("exception happened - here's what I know: ");
			e.printStackTrace();
			System.exit(-1);
		}

	}


}
