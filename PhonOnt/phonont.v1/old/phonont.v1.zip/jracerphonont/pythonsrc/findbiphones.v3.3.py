# -*- coding: utf-8 -*-
# try to write a unicode letter finder in python
#! /usr/bin/env python
import codecs
import sys #for call arguments
import operator # for sorting by value http://wiki.python.org/moin/HowTo/Sorting

#tokenize on letters (if the same letter, then consider 1 token)

#filename="InukMagazine102-104rough-inuktitut.txt"
#filename="inuktitut-unicode.txt"
filename= sys.argv[1]

intext = codecs.open(filename, encoding='utf-8')

filenameout=filename+"-biphones.txt"
outtext = codecs.open(filenameout, encoding='utf-8', mode='w')


dictionary = {}
charcount = {}
prevletter = ""
for line in intext:
    for letter in line:
        #adds a key or increments its count in the dictionary, if not whitespace
        if (letter.isspace() or letter.isdigit() or letter in ".,;:_!?=@+/(){}[]&-*%~$^" ):
		letter="@"#the symbol for word edges
	biphone=prevletter+letter
	prevletter=letter	
	if biphone in dictionary:
       	    dictionary[biphone] +=1
       	else:
       	    dictionary[biphone] = 1
	#print(biphone) 

#Sort the characters by most frequent and put into a list of tuples
sorted_list = sorted(dictionary.iteritems(),key=operator.itemgetter(1), reverse=True)

#Output the count of characters    
#pickle.dump(charcount,outtext)

#print sorted_list

totalcharcount=0
for x,y in sorted_list:
    x = unicode(x)
    totalcharcount = totalcharcount+y
    y= unicode(y)
    stringtoprint=x+"\t"+y+"\n"
    outtext.write(stringtoprint)

stringtoprint="\n"
outtext.write(stringtoprint)
#print totalcharcount
intext.close()
outtext.close()
