package com.racersystems.jracer;
import java.util.*;
import java.lang.Math;

public class AverageProductivityBySunlightQuery {

    public static void main(String[] args) {

	String ip = "localhost"; //start racerpro with  RacerPro -- -ef @UTF8 
	int port = 8088;
	String ont = "\"C:\\\\Program Files\\\\Protege_4.0.1\\\\RacerPro-20-Preview\\\\comp6531\\\\OCCSSERCFMv1.0.owl\"";
	String roomStr = "";
	final int MAXINT =  2147483647;

	RacerClient racer = new RacerClient(ip,port);		

	try {

	    racer.openConnection();

	    racer.loggingOn();
	    
	    racer.fullReset();   

		racer.owlReadFile(ont); 
		
		//get sunny productivity	
		int numSunnyProfs = 0;
		int numSunnyPubs = 0;   
//System.out.println("send raw");
		String sunnyStr = racer.sendRaw("(retrieve (?ProductiveWithSun (count ?y) (group-by ?ProductiveWithSun) )(and 	(?ProductiveWithSun ?y #!:hasPublication) (?ProductiveWithSun ?z #!:hasOffice ) (?z #!:SunnyOffice) ))");
//System.out.println(sunnyStr);

		//parse sunny productivity
		String[] sunnyStrs = sunnyStr.split("\\?y\\)\\s");
//System.out.println("num sunny : " + sunnyStrs.length);
		numSunnyProfs = sunnyStrs.length-1;
		for(int sunnyCounter = 1; sunnyCounter < sunnyStrs.length; sunnyCounter++){
			numSunnyPubs += Integer.parseInt(sunnyStrs[sunnyCounter].substring(0,sunnyStrs[sunnyCounter].indexOf(")")));
//System.out.println(Integer.parseInt(sunnyStrs[sunnyCounter].substring(0,sunnyStrs[sunnyCounter].indexOf(")"))));
		}	

		//get no window productivity
		int numNoWindowProfs = 0;
		int numNoWindowPubs = 0;   
//System.out.println("send raw");
		String noWindowStr = racer.sendRaw("(retrieve (?ProductiveWithNoWindow (count ?y) (group-by ?ProductiveWithNoWindow) )(and (?ProductiveWithNoWindow ?y #!:hasPublication)  (?ProductiveWithNoWindow ?z #!:hasOffice ) (?z ?x #!:hasFixture)(?x #!:NoWindow)))");
//System.out.println(noWindowStr);

		//parse no window productivity
		String[] noWindowStrs = noWindowStr.split("\\?y\\)\\s");
//System.out.println("num no win : " + noWindowStrs.length);
		numNoWindowProfs = noWindowStrs.length-1;
		for(int noWindowCounter = 1; noWindowCounter < noWindowStrs.length; noWindowCounter++){
			numNoWindowPubs += Integer.parseInt(noWindowStrs[noWindowCounter].substring(0,noWindowStrs[noWindowCounter].indexOf(")")));
//System.out.println(Integer.parseInt(noWindowStrs[noWindowCounter].substring(0,noWindowStrs[noWindowCounter].indexOf(")"))));
		}	

		//get no sun productivity
		int numNoSunProfs = 0;
		int numNoSunPubs = 0;   
//System.out.println("send raw");
		String noSunStr = racer.sendRaw("(retrieve (?ProductiveWithSunComplement (count ?y) (group-by ?ProductiveWithSunComplement) )(and (?ProductiveWithSunComplement ?y #!:hasPublication) (?ProductiveWithSunComplement ?z #!:hasOffice ) (?z #!:SunnyOffice) ))");
//System.out.println(noWindowStr);

		//parse no sun productivity
		String[] noSunStrs = noSunStr.split("\\?y\\)\\s");
//System.out.println("num no sun : " + noSunStrs.length);
		numNoSunProfs = noSunStrs.length-1;
		for(int noSunCounter = 1; noSunCounter < noSunStrs.length; noSunCounter++){
			numNoSunPubs += Integer.parseInt(noSunStrs[noSunCounter].substring(0,noSunStrs[noSunCounter].indexOf(")")));
//System.out.println(Integer.parseInt(noSunStrs[noSunCounter].substring(0,noSunStrs[noSunCounter].indexOf(")"))));
		}	

		//output results
		System.out.println("\n\n\nDo professors with sunnier offices have greater productivity?\n");
		System.out.println("The average publication per professor for professors with sunny windows is:       " + (float)numSunnyPubs/numSunnyProfs);
		System.out.println("The average publication per professor for professors with windows without sun is: " + (float)numNoSunPubs/numNoSunProfs);
		System.out.println("The average publication per professor for professors with no windows at all is:   " + (float)numNoWindowPubs/numNoWindowProfs);
		  
		//get members of clac
		String membersQueryString = racer.sendRaw("(retrieve (?student) (and (not (same-as ?student #!:Julien_Dubuc))	(?group #!:Julien_Dubuc  #!:hasMember)(?group ?student #!:hasMember)	))");
		System.out.println(membersQueryString);	


		
	} catch (Exception e) {

	    e.printStackTrace();
	    
	}
	
    }
    
}
