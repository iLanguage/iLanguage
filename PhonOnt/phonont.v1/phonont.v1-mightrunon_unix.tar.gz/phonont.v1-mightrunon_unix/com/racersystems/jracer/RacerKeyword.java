package com.racersystems.jracer;

public class RacerKeyword extends RacerSymbol {

    public RacerKeyword(String value) {
	super(value);
    }
}

