package com.racersystems.jracer;

public class RacerOWLAPITest {

    public static void main(String[] args) {

	String ip = "localhost";
	int port = 8088;

	RacerClient racer = new RacerClient(ip,port);		

	try {

	    racer.openConnection();

	    racer.loggingOn();
	    racer.sendRaw("(logging-on)");
	
	    racer.fullReset();

	    racer.owlapiNewReasoner("test");
	    System.out.println(racer.owlapiGetReasoners());

	    racer.owlapiNewOntology("test");
	    System.out.println(racer.owlapiGetOntologies());

	    racer.owlapiAutoAddAxiomsTo("test");

	    racer.owlapiParseNative("\"ClassAssertion(d j)\""); 
	    racer.owlapiParseNative("\"ObjectPropertyAssertion(r j k)\""); 


	    System.out.println(racer.owlapiGetAxioms("test"));	    


	} catch (Exception e) {

	    e.printStackTrace();
	    
	}
	
    }
    
}


