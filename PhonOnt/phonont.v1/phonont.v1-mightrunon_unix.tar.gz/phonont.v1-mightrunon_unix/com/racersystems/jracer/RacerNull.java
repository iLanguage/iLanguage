package com.racersystems.jracer;

public class RacerNull extends RacerResult {

    public String getValue() { return "RacerNull"; }

}




