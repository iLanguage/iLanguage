package com.racersystems.jracer;

public abstract class RacerLiteral extends RacerResult {}
