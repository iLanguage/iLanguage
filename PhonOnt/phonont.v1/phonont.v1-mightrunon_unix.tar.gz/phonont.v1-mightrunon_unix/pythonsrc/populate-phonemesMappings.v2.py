# -*- coding: utf-8 -*-
# try to write a unicode letter finder in python
#! /usr/bin/env python
import codecs
import sys #for call arguments
import operator # for sorting by value http://wiki.python.org/moin/HowTo/Sorting

#tokenize on letters (if the same letter, then consider 1 token)

language="Default"      #English, Inuktitut, Finnish, Korean
#segmentType="Phonemic" #Phonetic, Phonemic, Orthographic


filename= sys.argv[1]
language= sys.argv[2] 
intext = codecs.open(filename, encoding='utf-8')

filenameout=filename+"-tbox.txt"
outtext = codecs.open(filenameout, encoding='utf-8', mode='w')

for line in intext:
	letter=line.split()
	try:
                orthographicConcept=language+"_Orthographic_"+letter[0]+"_Letter"
                phonemicConcept="Phonemic_"+letter[1]+"_Letter"
                #Use this to create only concepts
                stringtoprint='<!-- http://openlanguage.ca/ontologies/phonont.v1#'+orthographicConcept+' -->\n\t<owl:Class rdf:about="#'+orthographicConcept+'">\n\t\t<rdfs:subClassOf rdf:resource="#'+phonemicConcept+'"/>\n\t</owl:Class>\n\n'
                outtext.write(stringtoprint)
        except IndexError, e:
                print ("Warning: ")
                print (e)

intext.close()
outtext.close()
