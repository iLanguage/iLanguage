# -*- coding: utf-8 -*-
# try to write a unicode letter finder in python
#! /usr/bin/env python
import codecs
import sys #for call arguments
import operator # for sorting by value http://wiki.python.org/moin/HowTo/Sorting


#tboxes = sys.argv[] #get the language from the 2rd position on each line in the letters file
#args = "pythonsrc\\data\\phonont-header.txt pythonsrc\\data\\phonont-footer.txt"
#tboxes = args.split()
#tboxes = sys.arv[]

filenameout=sys.argv[1]
#filenameout="pythonsrc\\phonont-tbox.owl"
outtext = codecs.open(filenameout, encoding='utf-8', mode='w')
assertionsCount=0

#for i in tboxes:
for i in sys.argv[2:]:
        #i=sys.argv[1]
        intext = codecs.open(i, encoding='utf-8')
        for line in intext:
                assertionsCount=assertionsCount+1
                #print(line)
                line = unicode(line)
                outtext.write(line)
        intext.close()

#for 2 assertions per letter assertionsTotal=(assertionsCount-22)/4.5
assertionsTotal=(assertionsCount-22)/5
#assertionsTotal=assertionsCount
print ("    The number of assertions written to file: ",assertionsTotal)

outtext.close()
